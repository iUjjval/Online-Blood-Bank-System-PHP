# bloodbank
This project was created for Receivers and Hospitals where a Hospital user can add blood sample to their blood bank and Receiver users can request for the blood sample. Skills has used like HTML, CSS, Bootstrap, JavaScript as a frontend, PHP as a backend and MySQL for the database.
